<x-guest-layout>
<div class="min-h-[80vh] grid place-items-center px-4">
<div class="w-full max-w-md">
<div class="rounded-2xl bg-white shadow-card ring-1 ring-slate-200 p-5 sm:p-6">
<x-validation-errors class="mb-4" />
{{ $slot ?? '' }}
</div>
</div>
</div>
</x-guest-layout>
